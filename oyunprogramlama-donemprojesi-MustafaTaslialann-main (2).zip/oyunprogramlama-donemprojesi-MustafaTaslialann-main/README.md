[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/gTiETg9a)

Proje önerimin pdfi ektedir.
[MUSTAFA_TASLIALAN_192503063_PROJE_Onerisi.pdf](https://github.com/Iskenderun-Technical-University/donem-projesi-MustafaTaslialann/files/11260631/MUSTAFA_TASLIALAN_192503063_PROJE_Onerisi.pdf)
 
 Projemin tüm kodları futbol oyunu dosyasındadır.
